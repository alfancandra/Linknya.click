<div>
    <h1 class="text-light text-center">Create Fastest URL Shortener</h1>
    <div class="card">
        <div class="card-header pl-2 pr-2 mt-3">
            <form wire:submit.prevent="submit">
                <div class="input-group mb-3">
                    <input type="text" wire:model="link" class="form-control <?php $__errorArgs = ['link'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Enter URL"
                        aria-label="Recipient's username" aria-describedby="basic-addon2">
                    <div class="input-group-append">
                        <button class="btn btn-primary" type="submit">Generate Shorten Link</button>
                    </div>
                </div>
                <?php $__errorArgs = ['link'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </form>
        </div>
    </div>

    <?php if(session()->has('message')): ?>
    <div class="card">
        <div class="card-header pl-2 pr-2 mt-3">
            <?php echo e(session('message')); ?>

        </div>
    </div>
    <?php endif; ?>
    
</div>
<?php /**PATH E:\Coding\web\linknya\resources\views/livewire/shortlink/create.blade.php ENDPATH**/ ?>