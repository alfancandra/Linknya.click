<?php return array (
  'shortlink.create' => 'App\\Http\\Livewire\\Shortlink\\Create',
);